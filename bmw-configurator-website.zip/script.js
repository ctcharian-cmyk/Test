const questions = [
  {
    key: "carType",
    title: "What type of car do you like?",
    copy: "Start with the shape you prefer. Do you want a sedan, coupe, or SUV?",
    options: [
      { label: "Sedan", description: "A balanced BMW for everyday driving with a sporty feel.", price: 52000 },
      { label: "Coupe", description: "A lower, sharper two-door style for a more dramatic drive.", price: 58000 },
      { label: "SUV", description: "A roomier BMW with comfort, cargo space, and road presence.", price: 72000 }
    ]
  },
  {
    key: "personality",
    title: "What kind of BMW personality do you want?",
    copy: "Now choose the mood of the build: sportier, casual, or more luxury.",
    options: [
      { label: "Sportier", description: "Sharper handling, aggressive styling, and a more exciting drive.", price: 8500 },
      { label: "Casual", description: "Comfortable, simple, and easy to enjoy every day.", price: 0 },
      { label: "More luxury", description: "Premium materials, extra comfort, and a quieter ride.", price: 6500 }
    ]
  },
  {
    key: "color",
    title: "Choose your exterior color",
    copy: "A great build starts with the paint. Pick a color that matches the mood of your car.",
    options: [
      { label: "Alpine White", description: "Clean, bright, and classic.", price: 0, color: "#f5f7f8" },
      { label: "Black Sapphire", description: "Glossy, dramatic, and timeless.", price: 650, color: "#111318" },
      { label: "Portimao Blue", description: "Sporty blue with strong curb presence.", price: 650, color: "#245aa8" },
      { label: "Brooklyn Grey", description: "Modern grey with a technical look.", price: 650, color: "#8d939b" }
    ]
  },
  {
    key: "interior",
    title: "What interior feels right?",
    copy: "Choose the cabin style you would want to see every time you open the door.",
    options: [
      { label: "Black Sensatec", description: "Durable, simple, and easy to maintain.", price: 0 },
      { label: "Cognac Leather", description: "Warm premium leather with a luxury feel.", price: 1800 },
      { label: "Oyster Leather", description: "Light and airy with a clean upscale look.", price: 1800 },
      { label: "M Sport Black", description: "Bolstered seats, contrast stitching, and sporty trim.", price: 2600 }
    ]
  },
  {
    key: "tech",
    title: "Which technology package do you want?",
    copy: "Add the features that make your BMW feel more intelligent and effortless.",
    options: [
      { label: "Essential", description: "Navigation, wireless charging, and smartphone integration.", price: 1200 },
      { label: "Premium", description: "Head-up display, surround cameras, and upgraded audio.", price: 3600 },
      { label: "Driver Assistance", description: "Adaptive cruise, lane keeping, and parking assistance.", price: 4300 },
      { label: "Executive", description: "Premium plus comfort, audio, lighting, and assistance features.", price: 6500 }
    ]
  },
  {
    key: "wheels",
    title: "Finish it with wheels",
    copy: "Your wheel choice changes the stance of the car and the final price.",
    options: [
      { label: "18-inch Aero", description: "Efficient, comfortable, and understated.", price: 0 },
      { label: "19-inch Sport", description: "A confident upgrade with a sharper look.", price: 1200 },
      { label: "20-inch M Wheels", description: "Bold performance styling and wider tires.", price: 2600 },
      { label: "21-inch Individual", description: "Maximum presence for a premium build.", price: 3900 }
    ]
  }
];

const answers = {};
let currentStep = 0;

const stepLabel = document.querySelector("#stepLabel");
const questionTitle = document.querySelector("#questionTitle");
const questionCopy = document.querySelector("#questionCopy");
const optionsGrid = document.querySelector("#optionsGrid");
const progressFill = document.querySelector("#progressFill");
const pricePill = document.querySelector("#pricePill");
const backButton = document.querySelector("#backButton");
const nextButton = document.querySelector("#nextButton");
const resetButton = document.querySelector("#resetButton");
const restartButton = document.querySelector("#restartButton");
const downloadButton = document.querySelector("#downloadButton");
const summaryPanel = document.querySelector("#summaryPanel");
const summaryTitle = document.querySelector("#summaryTitle");
const summaryList = document.querySelector("#summaryList");
const navRow = document.querySelector(".nav-row");
const questionCard = document.querySelector(".question-card");

function money(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);
}

function getTotalPrice() {
  return Object.values(answers).reduce((total, answer) => total + answer.price, 0);
}

function getRecommendedModel() {
  const type = answers.carType?.label;
  const personality = answers.personality?.label;

  const recommendations = {
    Sedan: {
      Sportier: "BMW M340i Sedan",
      Casual: "BMW 330i Sedan",
      "More luxury": "BMW 530i Sedan"
    },
    Coupe: {
      Sportier: "BMW M440i Coupe",
      Casual: "BMW 430i Coupe",
      "More luxury": "BMW 840i Coupe"
    },
    SUV: {
      Sportier: "BMW X3 M40i",
      Casual: "BMW X3 xDrive30i",
      "More luxury": "BMW X5 xDrive40i"
    }
  };

  return recommendations[type]?.[personality] || "BMW build";
}

function renderQuestion() {
  const question = questions[currentStep];
  const selectedAnswer = answers[question.key];

  stepLabel.textContent = `Question ${currentStep + 1} of ${questions.length}`;
  questionTitle.textContent = question.title;
  questionCopy.textContent = question.copy;
  progressFill.style.width = `${((currentStep + 1) / questions.length) * 100}%`;
  pricePill.textContent = money(getTotalPrice() || questions[0].options[0].price);
  backButton.disabled = currentStep === 0;
  nextButton.disabled = !selectedAnswer;
  nextButton.textContent = currentStep === questions.length - 1 ? "See build" : "Next";

  optionsGrid.innerHTML = "";
  question.options.forEach((option) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "option-button";
    if (selectedAnswer?.label === option.label) {
      button.classList.add("is-selected");
    }

    const swatch = option.color
      ? `<span class="swatch" style="background: ${option.color}"></span>`
      : "";

    button.innerHTML = `
      <span class="option-title">${swatch}${option.label}</span>
      <span class="option-description">${option.description} ${option.price ? `+${money(option.price)}` : "Included"}</span>
    `;

    button.addEventListener("click", () => {
      answers[question.key] = option;
      renderQuestion();
    });

    optionsGrid.appendChild(button);
  });
}

function showSummary() {
  questionCard.hidden = true;
  navRow.hidden = true;
  summaryPanel.hidden = false;
  progressFill.style.width = "100%";
  stepLabel.textContent = "Complete";
  questionTitle.textContent = "Your BMW is configured";
  pricePill.textContent = money(getTotalPrice());

  const baseModel = getRecommendedModel();
  summaryTitle.textContent = `${baseModel} - ${money(getTotalPrice())}`;
  summaryList.innerHTML = "";

  questions.forEach((question) => {
    const answer = answers[question.key];
    const item = document.createElement("div");
    item.className = "summary-item";
    item.innerHTML = `
      <dt>${question.key}</dt>
      <dd>${answer.label}</dd>
    `;
    summaryList.appendChild(item);
  });
}

function restart() {
  Object.keys(answers).forEach((key) => delete answers[key]);
  currentStep = 0;
  questionCard.hidden = false;
  navRow.hidden = false;
  summaryPanel.hidden = true;
  renderQuestion();
}

function downloadBuild() {
  const lines = [
    "BMW Configurator Build",
    "======================",
    "",
    ...questions.map((question) => `${question.key}: ${answers[question.key].label}`),
    "",
    `Estimated price: ${money(getTotalPrice())}`
  ];

  const blob = new Blob([lines.join("\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "bmw-build.txt";
  link.click();
  URL.revokeObjectURL(url);
}

backButton.addEventListener("click", () => {
  if (currentStep > 0) {
    currentStep -= 1;
    renderQuestion();
  }
});

nextButton.addEventListener("click", () => {
  if (!answers[questions[currentStep].key]) return;

  if (currentStep === questions.length - 1) {
    showSummary();
    return;
  }

  currentStep += 1;
  renderQuestion();
});

resetButton.addEventListener("click", restart);
restartButton.addEventListener("click", restart);
downloadButton.addEventListener("click", downloadBuild);

renderQuestion();
